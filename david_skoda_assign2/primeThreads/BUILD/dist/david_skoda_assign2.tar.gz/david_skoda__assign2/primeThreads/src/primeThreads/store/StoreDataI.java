package primeThreads.store;

public interface StoreDataI {

		/**
		*	Insert a value into the classes data structure.
		*	@param obj some object to insert
		*/
    public void insert(Object obj);

} 
