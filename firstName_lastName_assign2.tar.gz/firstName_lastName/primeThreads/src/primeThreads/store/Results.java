
package primeThreads.store;

public class Results implements StdoutDisplayInterface {
    // appropriate data structure as private data member


    // appropriate method to save prime number to the data structure

    public void writeSumToScreen() {
	// ..
    }
} 


