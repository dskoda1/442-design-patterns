
package primeThreads.util;

public class IsPrime {

}
