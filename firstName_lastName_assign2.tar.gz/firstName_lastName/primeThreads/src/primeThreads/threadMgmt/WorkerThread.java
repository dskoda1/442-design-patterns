
package primeThreads.threadMgmt;

public class WorkerThread implements Runnable  {


    public void run() {
	// ...
    }
    

}