
package primeThreads.threadMgmt;

public class CreateWorkers  {

    // this class has the method startWokers(...)

}