
package primeThreads.driver;

public class Driver{

	public static void main(String args[]) {

		System.out.println("\n The args[0] is: " + args[0]);


	} // end main(...)

} // end public class Driver

