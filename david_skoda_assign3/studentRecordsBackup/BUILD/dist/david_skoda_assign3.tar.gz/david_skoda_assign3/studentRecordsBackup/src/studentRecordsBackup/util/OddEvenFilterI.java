package studentRecordsBackup.util;

public interface OddEvenFilterI{

	public boolean check(Object obj);
}
